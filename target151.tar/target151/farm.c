/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_319(unsigned x)
{
    return x + 3347660952U;
}

void setval_289(unsigned *p)
{
    *p = 3281016926U;
}

unsigned getval_320()
{
    return 2425393224U;
}

unsigned addval_467(unsigned x)
{
    return x + 3347663071U;
}

void setval_369(unsigned *p)
{
    *p = 3348711445U;
}

unsigned getval_386()
{
    return 3277378597U;
}

unsigned getval_124()
{
    return 3284633928U;
}

unsigned getval_471()
{
    return 2425394264U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_209()
{
    return 3767093388U;
}

unsigned addval_407(unsigned x)
{
    return x + 3375942281U;
}

void setval_140(unsigned *p)
{
    *p = 3532969609U;
}

void setval_363(unsigned *p)
{
    *p = 2425471369U;
}

unsigned getval_207()
{
    return 3229928137U;
}

unsigned getval_434()
{
    return 3525888649U;
}

unsigned addval_491(unsigned x)
{
    return x + 3285617091U;
}

void setval_302(unsigned *p)
{
    *p = 3374369409U;
}

unsigned addval_276(unsigned x)
{
    return x + 3771287684U;
}

unsigned addval_303(unsigned x)
{
    return x + 2430634314U;
}

unsigned addval_477(unsigned x)
{
    return x + 3531915661U;
}

void setval_187(unsigned *p)
{
    *p = 2430634312U;
}

unsigned getval_288()
{
    return 3372799497U;
}

void setval_206(unsigned *p)
{
    *p = 3380922889U;
}

void setval_111(unsigned *p)
{
    *p = 3286272329U;
}

unsigned addval_476(unsigned x)
{
    return x + 3599591741U;
}

unsigned getval_350()
{
    return 3353381192U;
}

unsigned getval_168()
{
    return 3375939977U;
}

void setval_405(unsigned *p)
{
    *p = 3676883593U;
}

unsigned addval_165(unsigned x)
{
    return x + 3682910600U;
}

unsigned addval_451(unsigned x)
{
    return x + 3766568996U;
}

unsigned getval_263()
{
    return 3676881289U;
}

void setval_301(unsigned *p)
{
    *p = 3372794281U;
}

unsigned getval_305()
{
    return 3375415689U;
}

unsigned getval_382()
{
    return 3771287633U;
}

unsigned getval_438()
{
    return 3281049225U;
}

void setval_445(unsigned *p)
{
    *p = 3523267209U;
}

unsigned getval_425()
{
    return 3348158089U;
}

void setval_180(unsigned *p)
{
    *p = 3375421065U;
}

unsigned getval_488()
{
    return 3526934921U;
}

unsigned getval_108()
{
    return 3677935273U;
}

unsigned getval_441()
{
    return 3221801609U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
